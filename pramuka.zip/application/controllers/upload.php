<?php 
class Upload extends CI_Controller{
 
	function __construct(){
		parent::__construct();
		  $this->load->helper(array('form', 'url'));
		  $this->load->model('m_tampil');
	}
 
	public function index(){
		$data['data'] = $this->m_tampil->tampil_gambar()->result();
		// $data = array('error' => ' ' );
		$this->load->view('v_upload', $data);
	}
 
	public function aksi_upload(){
		$config['upload_path']          = './gambar/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
 
		$this->load->library('upload', $config);



		if ( ! $this->upload->do_upload('berkas')){
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('v_upload', $error);
		}else{
			$gambar = array('nama_file' => $_FILES['berkas']['name']);
 			$this->m_tampil->input_gambar($gambar);
			$data = array('upload_data' => $this->upload->data());
			$this->load->view('v_upload_sukses', $data);
		}
	}
	
}
 ?>