<?php defined("BASEPATH") OR exit("No direct script access allowed");

$route["id"] = "home/index";
$route["id/post/(:any)"] = "home/post/$1";
$route["id/gallery"] = "home/gallery";
$route["id/contact"] = "home/contact";
$route["id/category/(:any)"] = "home/category/$1";
$route["id/profile/(:any)"] = "home/profile/$1";
$route["id/tag/(:any)"] = "home/tag/$1";
$route["id/reading-list"] = "home/reading_list";
$route["id/search"] = "home/search";
$route["id/rss-feeds"] = "home/rss_feeds";
$route["id/rss/posts"] = "rss/rss_all_posts";
$route["id/rss/popular-posts"] = "rss/rss_popular_posts";
$route["id/rss/category/(:any)"] = "rss/rss_by_category/$1";
$route["id/login"] = "auth/login";
$route["id/register"] = "auth/register";
$route["id/profile-update"] = "auth/update_profile";
$route["id/change-password"] = "auth/change_password";
$route["id/reset-password"] = "auth/reset_password";
$route["id/(:any)"] = "home/get_page/$1";

?>