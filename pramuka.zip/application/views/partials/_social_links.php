<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<style>
    i{
        color: white;
    }
</style>
<!--if facebook url exists-->
<?php if (!empty($settings->facebook_url)) : ?>
    <li>
        <a class="facebook" href="<?php echo html_escape($settings->facebook_url); ?>"
           target="_blank"><i class="fa fa-facebook-square fa-2x"></i></a>
    </li>
<?php endif; ?>
<!--if twitter url exists-->
<?php if (!empty($settings->twitter_url)) : ?>
    <li>
        <a class="twitter" href="<?php echo html_escape($settings->twitter_url); ?>"
           target="_blank"><i
                class="fa fa-twitter-square fa-2x"></i></a>
    </li>
<?php endif; ?>
<!--if google url exists-->
<?php if (!empty($settings->google_url)) : ?>
    <li>
        <a class="google" href="<?php echo html_escape($settings->google_url); ?>"
           target="_blank">
            <i class="fa fa-google-plus-square fa-2x"></i>
        </a>
    </li>
<?php endif; ?>
<!--if pinterest url exists-->
<?php if (!empty($settings->pinterest_url)) : ?>
    <li>
        <a class="pinterest" href="<?php echo html_escape($settings->pinterest_url); ?>"
           target="_blank"><i
                class="fa fa-pinterest-square fa-2x"></i></a>
    </li>
<?php endif; ?>
<!--if instagram url exists-->
<?php if (!empty($settings->instagram_url)) : ?>
    <li>
        <a class="instgram" href="<?php echo html_escape($settings->instagram_url); ?>"
           target="_blank"><i
                class="fa fa-instagram fa-2x"></i></a>
    </li>
<?php endif; ?>
<!--if linkedin url exists-->
<?php if (!empty($settings->linkedin_url)) : ?>
    <li>
        <a class="linkedin" href="<?php echo html_escape($settings->linkedin_url); ?>"
           target="_blank"><i
                class="fa fa-linkedin fa-2x"></i></a>
    </li>
<?php endif; ?>
<!--if vk url exists-->
<?php if (!empty($settings->vk_url)) : ?>
    <li>
        <a class="vk" href="<?php echo html_escape($settings->vk_url); ?>"
           target="_blank"><i class="fa fa-vk fa-2x"></i></a>
    </li>
<?php endif; ?>

<!--if rss active-->
<!-- <?php if ($general_settings->show_rss == 1) : ?>
    <li>
        <a class="rss" href="<?php echo lang_base_url(); ?>rss-feeds"><i class="fa fa-rss"></i></a>
    </li>
<?php endif; ?> -->