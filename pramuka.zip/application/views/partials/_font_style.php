<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<style>
    body {
    <?php echo $primary_font_family; ?>
    }

    .widget-title .title, .home-slider-item .title, .reactions .title-reactions, .poll .title, .w-popular-list li .title, .random-post-slider .item-info .title, .first-tmp-slider-item .item-info .title, .post-item-horizontal .title, .post-item .title, .footer-widget .title, .f-random-list li .title, .post-content .post-title .title, .related-posts .post-list li .title, .related-posts .related-post-title .title, .comment-tabs a, .page-title, .leave-reply-title, .post-item-boxed .title, .w-our-picks-list li .title {
    <?php echo $secondary_font_family; ?>
    }

    .text-style {
    <?php echo $tertiary_font_family; ?>
    }
</style>