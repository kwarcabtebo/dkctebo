<div class="col-sm-12 widget-body ">
    <div class="row" >

    	<?php $kepala_sekolah = $this->db->query("SELECT * FROM pages WHERE slug ='sambutan'");?>
    	<?php if ($kepala_sekolah->num_rows() > 0 ) { ?>
    		<?php $conten = $kepala_sekolah->row(); ?>
        <h4 class="widget-title">Sambutan</h4>
            <div class="box"style="height:150px auto;width:auto;padding:10px;background-color:#e67e22;border-radius:5px;">
            <img src="<?php echo base_url('assets/img/kepala-sekolah.jpg') ?>" style="border-radius: 5%;height: 100px;width: 100px;box-shadow: 2px 2px 7px black;float: left;margin-right:15px " alt="test">
            <p style="padding: 10px;width: 350px; color: white;"><?php echo character_limiter($conten->page_content, 165, '...'); ?></p><a href="<?php echo base_url(). $conten->slug ?>" class="btn btn-info btn-sm float-right" style="background:#4a86ff;">Detail</a>
            </div>
        <?php } ?>
    </div>
</div>