<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="sidebar">
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v4.0"></script>
    <?php $this->load->view("partials/_ad_spaces", ["ad_space" => "sidebar_top"]); ?>
    <div class="col-sm-12 col-xs-12 sidebar-widget widget-popular-posts">
        <div class="row">
            <!--Include popular posts partial-->
            <?php $this->load->view('partials/_kepala_sekolah'); ?>
        </div>
    </div>
    <div class="col-sm-12 col-xs-12 sidebar-widget widget-popular-posts">
        <div class="row">
            <!--Include popular posts partial-->
            <?php //$this->load->view('partials/_popular_posts'); ?>
        </div>
    </div>


    <?php if (count($our_picks) > 0): ?>
        <div class="col-sm-12 col-xs-12 sidebar-widget">
            <div class="row">
                <!--Include our picks partial-->
                <?php $this->load->view('partials/_our_picks'); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-sm-12 col-xs-12 sidebar-widget">
        <div class="row">
            <!--Include categories partial-->
            <?php $this->load->view('partials/_categories'); ?>
        </div>
    </div>

    <?php $this->load->view("partials/_ad_spaces", ["ad_space" => "sidebar_bottom"]); ?>

    <div class="col-sm-12 col-xs-12 sidebar-widget">
        <div class="row">
            <!--Include random slider partial-->
            <?php $this->load->view('partials/_random_slider'); ?>
        </div>
    </div>

    <div class="col-sm-12 col-xs-12 sidebar-widget widget-popular-posts">
        <div class="row">
            <h4 class="widget-title"><span class="glyphicon glyphicon-send" aria-hidden="true"> </span> Halaman</h4>
            <div class="fb-page" data-href="https://www.facebook.com/kwarnas/" data-tabs="timeline" data-width="" data-height="400" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/kwarnas/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/kwarnas/">Kwartir Nasional Gerakan Pramuka</a></blockquote></div>
        </div>
    </div>
    <div class="col-sm-12 col-xs-12 sidebar-widget">
        <div class="row">
            <!--Include tags partial-->
            <?php $this->load->view('partials/_tags'); ?>
        </div>
    </div>
    <div class="col-sm-12 col-xs-12 sidebar-widget">
        <div class="row">
            <!--Include Widget Comments-->
            <?php $this->load->view('partials/_sidebar_widget_polls'); ?>
        </div>
    </div>

</div><!--/Sidebar-->