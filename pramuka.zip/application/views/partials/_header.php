<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en-US">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo html_escape($title); ?> - <?php echo html_escape($settings->site_title); ?></title>
    <meta name="description" content="<?php echo html_escape($description); ?>"/>
    <meta name="keywords" content="<?php echo html_escape($keywords); ?>"/>
    <meta name="author" content="Codingest"/>
    <meta name="robots" content="all"/>
    <meta name="revisit-after" content="1 Days"/>
    <meta property="og:locale" content="en_US"/>
    <meta property="og:site_name" content="<?php echo $settings->application_name; ?>"/>
<?php if (isset($page_type)): ?>
    <meta property="og:type" content="<?php echo $og_type; ?>"/>
    <meta property="og:title" content="<?php echo html_escape($post->title); ?>"/>
    <meta property="og:description" content="<?php echo html_escape($post->summary); ?>"/>
    <meta property="og:url" content="<?php echo $og_url; ?>"/>
    <meta property="og:image" content="<?php echo $og_image; ?>"/>
    <meta property="og:image:width" content="750"/>
    <meta property="og:image:height" content="415"/>
    <meta name="twitter:card" content=summary/>
    <meta name="twitter:title" content="<?php echo html_escape($post->title); ?>"/>
    <meta name="twitter:description" content="<?php echo html_escape($post->summary); ?>"/>
    <meta name="twitter:image" content="<?php echo $og_image; ?>"/>
<?php foreach ($og_tags as $tag): ?>
    <meta property="article:tag" content="<?php echo $tag->tag; ?>"/>
<?php endforeach; ?>
<?php else: ?>
    <meta property="og:type" content=website/>
    <meta property="og:title" content="<?php echo html_escape($title); ?> - <?php echo html_escape($settings->site_title); ?>"/>
    <meta property="og:description" content="<?php echo html_escape($description); ?>"/>
    <meta property="og:url" content="<?php echo base_url(); ?>"/>
    <meta name="twitter:card" content=summary/>
    <meta name="twitter:title" content="<?php echo html_escape($title); ?> - <?php echo html_escape($settings->site_title); ?>"/>
    <meta name="twitter:description" content="<?php echo html_escape($description); ?>"/>
<?php endif; ?>
    <link rel="canonical" href="<?php echo base_url(); ?>"/>
<?php if ($general_settings->multilingual_system == 1):
foreach ($languages as $language):
if ($language->id == $site_lang->id):?>
    <link rel="alternate" href="<?php echo base_url(); ?>" hreflang="<?php echo $language->language_code ?>"/>
<?php else: ?>
    <link rel="alternate" href="<?php echo base_url() . $language->short_form . "/"; ?>" hreflang="<?php echo $language->language_code ?>"/>
<?php endif; endforeach; endif; ?>
<?php if (empty($general_settings->favicon_path)): ?>
    <link rel="shortcut icon" type="image/png" href="<?php echo base_url(); ?>assets/img/favicon.png"/>
<?php else: ?>
    <link rel="shortcut icon" type="image/png" href="<?php echo base_url() . html_escape($general_settings->favicon_path); ?>"/>
<?php endif; ?>
    <?php echo $primary_font_url; ?>
    <?php echo $secondary_font_url; ?>
    <?php echo $tertiary_font_url; ?>
    <!-- Font-awesome CSS -->
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet"/>
    <link href="<?php echo base_url(); ?>assets/google-font/google-fonts.css" rel="stylesheet"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <!-- Owl-carousel CSS -->
    <link href="<?php echo base_url(); ?>assets/plugins/owl-carousel/owl.carousel.min.css" rel="stylesheet"/>
    <link href="<?php echo base_url(); ?>assets/plugins/owl-carousel/owl.theme.default.min.css" rel="stylesheet"/>
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/icheck/minimal/grey.css"/>
    <!-- Jquery Confirm CSS -->
    <link href="<?php echo base_url(); ?>assets/plugins/jquery-confirm/jquery-confirm.min.css" rel="stylesheet"/>
    <!-- Magnific Popup CSS -->
    <link href="<?php echo base_url(); ?>assets/css/magnific-popup.css" rel="stylesheet"/>
    <!-- Style CSS -->
    <link href="<?php echo base_url(); ?>assets/css/style.min.css" rel="stylesheet"/>
    <!-- Color CSS -->
<?php if ($general_settings->site_color == '') : ?>
    <link href="<?php echo base_url(); ?>assets/css/colors/default.min.css" rel="stylesheet"/>
<?php else : ?>
    <link href="<?php echo base_url(); ?>assets/css/colors/<?php echo html_escape($general_settings->site_color); ?>.min.css" rel="stylesheet"/>
<?php endif; ?>
    <!-- Responsive CSS -->
    <link href="<?php echo base_url(); ?>assets/css/responsive.min.css" rel="stylesheet"/>
<?php if ($selected_lang->text_direction == "rtl"): ?>
    <!-- RTL -->
    <link href="<?php echo base_url(); ?>assets/css/rtl.min.css" rel="stylesheet"/>
<?php endif; ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Jquery -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.12.4.min.js"></script>
<?php echo $general_settings->google_analytics; ?>
<?php echo $general_settings->head_code; ?>
<?php $this->load->view('partials/_font_style'); ?>
<?php if ($selected_lang->text_direction == "rtl"): ?>
    <script>var rtl = true;</script>
<?php else: ?>
    <script>var rtl = false;</script>
<?php endif; ?>
    <script>
        var csfr_token_name = '<?php echo $this->security->get_csrf_token_name(); ?>';
        var csfr_cookie_name = '<?php echo $this->config->item('csrf_cookie_name'); ?>';
        var base_url = '<?php echo base_url(); ?>';
    </script>

</head>

<body>
<!-- header -->
<header id="header">
    <?php if ($this->uri->segment(1) == '' ) {
     ?>
      <?php $ad_codes = helper_get_ad_codes('index_top'); ?>
    <div class="background" style="min-height: 550px;  background-size: cover; color:white; background-image:url(<?php echo $ad_codes->ad_code_728; ?>);">

        
<!--  <div class="carousel slide hidden-xs" data-ride="carousel" style="position: absolute;">
  <div class="carousel-inner">
  
    <div class="item active" >
      <img src="<?php echo $ad_codes->ad_code_728; ?>" alt="Demo 1">
    </div>

    <div class="item">
      <img src="<?php echo $ad_codes->ad_code_728; ?>" alt="Demo 2">
    </div>

    <div class="item">
      <img src="<?php echo $ad_codes->ad_code_728; ?>" alt="Demo 3">
    </div>
    
  </div>
</div> -->
        <div style="background: black;width: 100%;height:  555px;position: absolute;top:0;left: 0;opacity: 0.4;"></div>
       <div class="container">
                <nav class="navbar navbar-inverse" style="background-color: #ecf0f100; padding-top: 30px;">
       
               
       
                  
            <div class="navbar-header" style="background-color: #ecf0f100">

             

            </div>
             
                <a href="<?php echo base_url(); ?>" width="80px" style="text-decoration: none;color: white;">
                <img class="navbar-brand" alt="logo" src="<?php echo base_url('assets/img/logo.png') ?>">
                <h3 style="color: white; font-size: 19px;font-weight: bold;">KABUPATEN TEBO.
                    <ul class="nav navbar-nav navbar-right hidden-xs"></a>
                       
                        <?php $this->load->view("partials/_social_links"); ?>
                    </ul></h3>
              

    </nav>

           <div class="row">
               <div class="col-md-6">
                   <h3 class="title" style="font-size: 27px;padding-top: 50px ;padding-bottom:2px; font-weight: bold; text-shadow:2px 0px 1px 3px #000000;">Website Gerakan Pramuka Kwarcab Tebo </h3>
                   <h4 style="font-size: 20px; font-weight: bold;line-height: 22px; ">"Satyaku Ku Dharmakan Dharmaku ku baktikan"</h4>
                   <!-- <font color="white">Satyaku Ku Dharmakan Dharmaku ku baktikan</font> -->
                   
               </div>
           </div>

        </div>
     </div>

<?php } ?>
    
    <nav class="navbar navbar-inverse " style="background-color:#d35400;box-shadow: 1px 2px 7px #0000006b">

        <div style="background:#e67e22;width: 80%;height:  100%;position: absolute;top:0;left: 0;">
        </div>
        <div style="background:#4a86ff;width: 70%;height:  100%;position: absolute;top:0;left: 0;">
        </div>
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg" style="position: absolute;height: 100%;width: 5%;margin-left:80%;  ">
            <polygon style="fill:#e67e22;" points="0 0 2560 100 0 100"></polygon>
          </svg>
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg" style="position: absolute;height: 100%;width: 5%;margin-left:70%;  ">
            <polygon class="fill-white" points="0 0 2560 100 0 100"></polygon>
          </svg>
          
       
               
        <div class="container nav-container">
                  
            <div class="navbar-header">

                <!-- <div class="social-mobile">

                    <div class="col-sm-12">
                        <div class="row">
                            <ul class="nav navbar-nav" >


                                <?php //$this->load->view("partials/_social_links"); ?>
                            </ul>
                        </div>
                    </div>
                </div>
 -->
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a href="#" data-toggle="modal-search" class="search-icon mobile-search-icon"><i
                            class="fa fa-search"></i></a>

                <a class="navbar-brand" href="<?php echo lang_base_url(); ?>">
                    <img src="<?php echo get_logo($general_settings); ?>" alt="logo">
                </a>
                    <h4 class="navbar-text hidden-md hidden-lg" style="color:white;padding-top:10px;">Pramuka Kwarcab Tebo</h4>
            </div>


            <?php $this->load->view("partials/_nav.php"); ?>


        </div><!--/.container-->
    </nav>
    <div class="modal-search">
        <?php echo form_open(lang_base_url() . 'search', ['method' => 'get']); ?>
        <div class="container">
            <input type="text" name="q" class="form-control" maxlength="300" pattern=".*\S+.*"
                   placeholder="<?php echo html_escape(trans("search_exp")); ?>" required <?php echo ($rtl == true) ? 'dir="rtl"' : ''; ?>>
            <i class="fa fa-times s-close"></i>
        </div>
        <?php echo form_close(); ?>
    </div><!-- /.modal-search -->

<style>
    h1,h2,h3,h4,h5,h6,li{
        font-family: 'Prompt', sans-serif;
    }
    p{
        font-family: 'Raleway', sans-serif;
    }
    a{
       font-family: 'Raleway', sans-serif;
    }
    .navbar-inverse .navbar-nav>li>a{
        color: white;
    }
    .fill-white{
        fill: #4a86ff;
        position: absolute;

    }
</style>
</header>
<!-- /.header-->




