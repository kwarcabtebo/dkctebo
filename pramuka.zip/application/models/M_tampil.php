<?php 
class M_tampil extends CI_Model{
	function tampil_data(){
	return $this->db->query('SELECT a.id, a.nama, a.nis, a.tanggal, b.kelas FROM tb_siswa a INNER JOIN tb_kelas b ON a.kelas = b.id');
	}
	function tambah_data($table){
	return $this->db->insert('tb_siswa', $table);
	}
	function tambah_kelas($kelas){
	return $this->db->insert('tb_kelas',$kelas);
	}
	function input_gambar($file){
	return $this->db->insert('tb_file',$file);
	}
	function tampil_gambar(){
	return $this->db->get('tb_gambar');
	}
	function tampil_kelas(){
	return $this->db->get('tb_kelas');
	}
	function hapus($data,$hapus){
		$this->db->where($hapus);
		$this->db->delete($data);
		
	}
}



 ?>
